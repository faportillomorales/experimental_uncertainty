import uncertainties as unc
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime
from CoolProp.CoolProp import PropsSI
import sys

####################################################################################################################################################
#                                            INPUTS
####################################################################################################################################################
file_path = 'example/AWU90/AWU90P01/AWU90P01' #Insira o caminho do arquivo a ser analisado NOTE: USE SEMPRE A BARRA NORMAL '/', SE ESTIVER INVERTIDA, MODIFIQUE-A

L = 1.70         # m comprimento entre as tomadas de diferencial de pressão

# Valores de calibração do densitômetro IMPORTANTE
I_g = 252883                     # Insira a intensidade padrão para o gás (Calibração do densitômetro)
I_f = 151287                      # Insira a intensidade padrão para o líquido (Calibração do densitômetro)

sensor_Yokogawa = 'PDT-M-0101D-30Kpa_mA'
sensor_Endress = 'PDT-M-0101-40kPa_mA'

### Colunas de interesse -> Insira o nome das colunas a plotar e avaliar do arquivo .dat
# Lista de colunas para análise: [nome_coluna, apelido, unidade]
colunas_analise = [
    [sensor_Yokogawa, r'\Delta P_{40\,kPa} / L', r'[Pa/m]'],
    [sensor_Endress, r'\Delta P_{30\,kPa} / L', r'[Pa/m]'],
    ['Alpha', r'\alpha', r''],
    ['J Agua corrigido', r'J_{water}', r'[m/s]'],
    ['J Ar corrigido', r'J_{air}', r'[m/s]'],
    ['FT-A-0302', r'Q_{air}', r'[m³/h]'],
    ['PIT-M-0101', r'Gauge\ Pressure', r'[Bar]'],
    ['TIT-M-0101', r'Temperature', r'[°C]'],
    ['rho_g', r'\rho_{air}', r'[kg/m³]']
]
####################################################################################################################################################
#       '                                   END INPUTS
####################################################################################################################################################
g = 9.81        # m/s² 
rho_s = 962     # kg/m³         Densidade do silicone nas tomadas do sensor Yokogawa

def get_constants():
    """Returns a dictionary of constants used in the script."""
    return {
        'g': 9.81,         # m/s² 
        'rho_s': 962       # kg/m³         Densidade do silicone nas tomadas do sensor Yokogawa
    }

CONSTANTS = get_constants()
g = CONSTANTS['g']
rho_s = CONSTANTS['rho_s']

def find_min_std_window(df: pd.DataFrame, column_name: str, min_window_size: float, max_window_size: float):
    """
    Encontra a janela de tempo com menor desvio padrão para uma coluna específica,
    testando diferentes tamanhos de janela dentro do intervalo especificado.
    Se min_window_size = max_window_size, usa um tamanho fixo de janela.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados
        column_name (str): Nome da coluna a ser analisada
        min_window_size (float): Tamanho mínimo da janela em segundos
        max_window_size (float): Tamanho máximo da janela em segundos
        
    Returns:
        tuple: (índice inicial, índice final, desvio padrão mínimo, tamanho ótimo da janela)
    """
    if column_name not in df.columns:
        raise ValueError(f"Coluna '{column_name}' não encontrada no DataFrame")
    
    if min_window_size > max_window_size:
        raise ValueError("O tamanho mínimo da janela deve ser menor ou igual ao tamanho máximo")
    
    min_std = float('inf')
    best_start_idx = 0
    best_end_idx = 0
    best_window_size = 0
    
    window_sizes_to_test = [min_window_size] if min_window_size == max_window_size else np.arange(min_window_size, max_window_size + 1, 1)

    for window_size in window_sizes_to_test:
        for i in range(len(df)):
            start_time = df['X_Value'].iloc[i]
            end_time = start_time + window_size
            
            end_idx_candidate = df[df['X_Value'] <= end_time].index[-1]
            
            if end_idx_candidate - i < 2:
                continue
                
            window_data = df[column_name].iloc[i:end_idx_candidate+1]
            current_std = window_data.std()
            
            actual_window_size = df['X_Value'].iloc[end_idx_candidate] - start_time
            if abs(actual_window_size - window_size) > window_size * 0.01:
                continue
            
            if current_std < min_std:
                min_std = current_std
                best_start_idx = i
                best_end_idx = end_idx_candidate
                best_window_size = window_size
    
    if min_std == float('inf'):
        raise ValueError(f"Não foi possível encontrar uma janela válida entre {min_window_size} e {max_window_size} segundos")
    
    return best_start_idx, best_end_idx + 1, min_std, best_window_size

def read_file(file_path: str):
    """
    Lê o arquivo e retorna um DataFrame do pandas.
    Os dados são lidos a partir do segundo ***End_of_Header***.
    Os nomes das colunas são lidos da linha após o segundo ***End_of_Header***.
    
    Args:
        file_path (str): Caminho para o arquivo
        
    Returns:
        tuple: (DataFrame com os dados, data do teste experimental)
    """
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    data_teste = None
    primeiro_header_end = False
    
    for line in lines:
        if '***End_of_Header***' in line:
            primeiro_header_end = True
            continue
            
        if not primeiro_header_end:
            if 'Date' in line:
                try:
                    data = line.strip().split('Date')[1].strip()
                    partes = data.split('/')
                    if len(partes) == 3:
                        data_teste = f"{partes[0]}/{partes[1]}/{partes[2]}"
                except:
                    pass
    
    header_count = 0
    header_end_idx = 0
    for i, line in enumerate(lines):
        if '***End_of_Header***' in line:
            header_count += 1
            if header_count == 2:
                header_end_idx = i + 1
                break
            
    column_names = [name.strip() for name in lines[header_end_idx].strip().split('\t')]

    df = pd.read_csv(file_path, 
                     sep='\t',
                     skiprows=header_end_idx+1,
                     decimal=',',
                     na_values=[''],
                     encoding='utf-8',
                     names=column_names)
    ###########CUIDADO HARD CODE CORREÇÃO DO J###############
    df['J Ar corrigido'] = df['J Ar'] * (1 - 0.06675) 
    df['J Agua corrigido'] = df['J Agua'] * (1 - 0.06675) 
    ###########CUIDADO HARD CODE CORREÇÃO DO J###############
    return df, data_teste

def format_filename(alias: str, unit: str) -> str:
    """
    Formats the filename by removing LaTeX characters and adding the unit.
    Example: r'\Delta P_{40\,kPa}' [Pa] -> Delta_P_40kPa [Pa]
    """
    name = alias.replace('\\', '')
    name = name.replace('{', '')
    name = name.replace('}', '')
    name = name.replace('\\,', '')
    name = name.replace('\\frac', '')
    name = name.replace('$', '')
    
    invalid_chars = ['|', '/', '\\', ':', '*', '?', '"', '<', '>', ',', ';', '=', ' ']
    for char in invalid_chars:
        name = name.replace(char, '_')
    
    while '__' in name:
        name = name.replace('__', '_')
    
    name = name.strip('_')
    
    if unit:
        unit = unit.replace('[', '').replace(']', '')
        name = f"{name}_{unit}"
    
    return name

def save_results(df: pd.DataFrame, coluna_escolhida: str, start_idx: int, end_idx: int, min_std: float, media_janela: float, 
                min_window_size: float, max_window_size: float, best_window_size: float, file_path: str, data_teste: str, 
                fluid_1: str, fluid_2: str, direction: str, theta: int, ID: str, nomes: list = None, medias: list = None, desvios: list = None, uAs: list = None,
                escolha_janela: str = None):
    """
    Salva os resultados da análise em um arquivo Excel.
    Agora inclui as estatísticas (média, desvio padrão, uA) de cada variável de interesse.
    """
    diretorio = os.path.dirname(file_path)
    base_name = os.path.splitext(os.path.basename(file_path))[0]
    
    output_file = os.path.join(diretorio, f"{base_name}_processed.xlsx")
    
    data_atual = datetime.now().strftime('%d/%m/%Y')
    
    header_info = {
        "Data do teste experimental": data_teste if data_teste else 'Não encontrada',
        "Data tratamento": data_atual,
        "Arquivo Original": file_path,
        "ID do ponto": ID,
        "Fluido 1": fluid_1,
        "Fluido 2": fluid_2,
        "Direção do escoamento": direction,
        "Inclinação (theta)": f"{theta}°",
        "Intensidade do gas densitometro (Ig)": I_g,
        "Intensidade do fluido densitometro (If)": I_f,
    }
    
    if escolha_janela == '1':
        header_info.update({
            "Tipo de Janela": "Manual",
            "Tamanho da Janela": f"{best_window_size:.1f} segundos",
            "Tempo Inicial": f"{df['X_Value'].iloc[start_idx]:.2f} segundos",
            "Tempo Final": f"{df['X_Value'].iloc[end_idx-1]:.2f} segundos",
            "Número de Pontos": end_idx - start_idx,
        })
    else:
        header_info.update({
            "Tipo de Janela": "Automática",
            "Coluna Critério": coluna_escolhida,
            "Tamanho Mínimo da Janela": f"{min_window_size:.1f} segundos",
            "Tamanho Máximo da Janela": f"{max_window_size:.1f} segundos",
            "Tamanho Ótimo da Janela": f"{best_window_size:.1f} segundos",
            "Média da Janela": f"{media_janela:.4f}",
            "Desvio Padrão": f"{min_std:.4f}",
            "Tempo Inicial": f"{df['X_Value'].iloc[start_idx]:.2f} segundos",
            "Tempo Final": f"{df['X_Value'].iloc[end_idx-1]:.2f} segundos",
            "Número de Pontos": end_idx - start_idx,
        })
    
    header_df = pd.DataFrame(list(header_info.items()), columns=['Parâmetro', 'Valor'])
    
    window_data = df.iloc[start_idx:end_idx]
    
    medias_janela = window_data.mean()
    
    colunas_corrigidas = []
    coluna_gravitacional = None
    
    for col in df.columns:
        if col.startswith('dP_F/dz dP_dz_total_'):
            colunas_corrigidas.append(col.replace('dP_F/dz dP_dz_total_', 'dP_dz_total_'))
        elif col.startswith('dP_F/dz dP_dz_gravitacional'):
            coluna_gravitacional = 'dP_dz_gravitacional'
        else:
            colunas_corrigidas.append(col)
    
    if coluna_gravitacional:
        colunas_corrigidas.append(coluna_gravitacional)
    
    medias_corrigidas = []
    dP_dz_total_values = {}  # Dicionário para armazenar os valores calculados
    for col in colunas_corrigidas:
        if col == 'dP_dz_gravitacional':
            medias_corrigidas.append(medias_janela['dP_F/dz dP_dz_gravitacional'])
        elif col.startswith('dP_dz_total_'):
            sensor_name = col.replace('dP_dz_total_', '')
            dP_F_col = f'dP_F/dz {sensor_name}'
            dP_F_series = window_data[dP_F_col]
            dP_F_RMS = np.sqrt(np.mean(np.square(dP_F_series)))
            grav_term = medias_janela['dP_F/dz dP_dz_gravitacional']
            if direction in ['Upward', 'Horizontal']:
                dP_dz_total = dP_F_RMS + grav_term
            else:
                dP_dz_total = -dP_F_RMS + grav_term
            medias_corrigidas.append(dP_dz_total)
            dP_dz_total_values[col] = dP_dz_total
        elif col.startswith('PDT-'):
            y_data = window_data[col]
            y_min = y_data.min()
            y_max = y_data.max()
            if (y_min/abs(y_min)) != (y_max/abs(y_max)):
                medias_corrigidas.append(np.sqrt(np.mean(np.square(y_data))))
            else:
                medias_corrigidas.append(y_data.mean())
        elif col.startswith('dP_F/dz PDT'):
            y_data = window_data[col]
            medias_corrigidas.append(np.sqrt(np.mean(np.square(y_data))))
        else:
            medias_corrigidas.append(medias_janela[col])
    
    resumo_dict = dict(zip(colunas_corrigidas, medias_corrigidas))
    
    resumo_df = pd.DataFrame([resumo_dict])
    
    window_df = pd.DataFrame()
    for col in colunas_corrigidas:
        if col == 'dP_dz_gravitacional':
            window_df[col] = window_data['dP_F/dz dP_dz_gravitacional']
        elif col.startswith('dP_dz_total_'):
            window_df[col] = dP_dz_total_values[col]
        else:
            window_df[col] = window_data[col]
    
    window_df.insert(0, 'Time (s)', window_data['X_Value'])
    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        header_df.to_excel(writer, sheet_name='Info', index=False)
        
        resumo_df.to_excel(writer, sheet_name='Resumo Medias', index=False, header=True)
        
        window_df.to_excel(writer, sheet_name='Serie Temporal', index=False)
    

def plot_time_series(df, colunas, output_dir, base_name):
    """
    Plota as séries temporais em subplots organizados em duas colunas e salva a imagem.
    colunas: lista de listas [nome_coluna, apelido, unidade]
    """
    n_colunas = 3
    n_linhas = (len(colunas) + n_colunas - 1) // n_colunas
    
    fig, axs = plt.subplots(n_linhas, n_colunas, figsize=(16, 3.8*n_linhas), constrained_layout=True)
    fig.suptitle('Séries Temporais das Variáveis', fontsize=18, y=1.03)
    
    for idx, coluna_info in enumerate(colunas):
        if isinstance(coluna_info, (list, tuple)) and len(coluna_info) == 3:
            nome_coluna, apelido, unidade = coluna_info
        else:
            nome_coluna = coluna_info
            apelido = nome_coluna
            unidade = ''
        linha = idx // n_colunas
        col = idx % n_colunas
        ax = axs[linha, col] if n_linhas > 1 else axs[col]
        if nome_coluna.startswith('PDT-'):
            y_data = df[nome_coluna]/L
            rms_pdt = np.sqrt(np.mean(np.square(y_data)))
            ax.plot(df['X_Value'], y_data, 'b-', alpha=0.8)
        else:
            y_data = df[nome_coluna]
            ax.plot(df['X_Value'], y_data, 'b-', alpha=0.8)
        media_serie = y_data.mean()
        desvio_serie = y_data.std()
        
        y_min = y_data.min()
        y_max = y_data.max()

        if 'PDT' in nome_coluna:
            if y_min >= 0:
                margem_min = y_min * 0.99
                margem_max = y_max * 1.01
            elif y_max <= 0:
                margem_min = y_min * 1.01
                margem_max = y_max * 0.99
            else:
                max_abs = max(abs(y_min), abs(y_max))
                margem_min = -max_abs * 1.01
                margem_max = max_abs * 1.01
        else:
            margem_min = y_min * 0.99
            margem_max = y_max * 1.01
            
        ax.set_ylim(margem_min, margem_max)
        
        ax.axhline(y=media_serie, color='g', linestyle='--', label=f'Mean: {media_serie:.4f}')
        ax.axhline(y=media_serie + desvio_serie, color='r', linestyle=':', label=f'std: ±{desvio_serie:.4f}')
        if nome_coluna.startswith('PDT-') and (y_min/abs(y_min)) != (y_max/abs(y_max)):
            ax.axhline(y=rms_pdt, color='g', linestyle='-', label=f'RMS: {rms_pdt:.4f}')
        ax.axhline(y=media_serie - desvio_serie, color='r', linestyle=':')
        ax.legend(fontsize=8, loc='upper right')
        if linha == n_linhas - 1:
            ax.set_xlabel('Time (s)', fontsize=11)
        ax.set_ylabel(f"${apelido}$ {unidade}", fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='both', which='major', labelsize=9)
       
        
        
    for idx in range(len(colunas), n_linhas * n_colunas):
        linha = idx // n_colunas
        col = idx % n_colunas
        fig.delaxes(axs[linha, col])
    output_path = os.path.join(output_dir, f"series_full-{base_name}.png")
    plt.savefig(output_path)
    plt.show()
    plt.close(fig)

def plot_windows(df, colunas, start_idx, end_idx, best_window_size, output_dir, base_name):
    """
    Plota as janelas de todas as variáveis em subplots organizados em duas colunas e salva a imagem.
    colunas: lista de listas [nome_coluna, apelido, unidade]
    """
    n_colunas = 3
    n_linhas = (len(colunas) + n_colunas - 1) // n_colunas
    fig, axs = plt.subplots(n_linhas, n_colunas, figsize=(16, 3.8*n_linhas), constrained_layout=True)
    fig.suptitle(f'Janelas das Variáveis (Tamanho: {best_window_size:.1f}s)', fontsize=18, y=1.03)
    for idx, (coluna, apelido, unidade) in enumerate(colunas):
        linha = idx // n_colunas
        col = idx % n_colunas
        ax = axs[linha, col] if n_linhas > 1 else axs[col]
        nome_coluna = coluna
        if nome_coluna.startswith('PDT-'):
            y_data = (df[nome_coluna].iloc[start_idx:end_idx])/L
            y_data_full = (df[nome_coluna])/L
            rms_pdt_win = np.sqrt(np.mean(np.square(y_data)))
            ax.plot(df['X_Value'], y_data_full, 'b-', alpha=0.3, label='Full Series (abs)')
            ax.plot(df['X_Value'].iloc[start_idx:end_idx], y_data, 'r-', alpha=0.8, label=f'Window = {best_window_size:.0f} s')
        else:
            y_data = df[nome_coluna].iloc[start_idx:end_idx]
            y_data_full = df[nome_coluna]
            ax.plot(df['X_Value'], df[nome_coluna], 'b-', alpha=0.3, label='Full Series')
            ax.plot(df['X_Value'].iloc[start_idx:end_idx], y_data, 'r-', alpha=0.8, label=f'Window = {best_window_size:.0f} s')
        media_janela = y_data.mean()
        media_serie = np.mean(df[nome_coluna])
        desvio_janela = y_data.std()
        
        y_min = y_data_full.min()
        y_max = y_data_full.max()
        
        if 'PDT' in nome_coluna:
            if y_min >= 0:
                margem_min = y_min * 0.99
                margem_max = y_max * 1.01
            elif y_max <= 0:
                margem_min = y_min * 1.01
                margem_max = y_max * 0.99
            else:
                max_abs = max(abs(y_min), abs(y_max))
                margem_min = -max_abs * 1.01
                margem_max = max_abs * 1.01
        else:
            margem_min = y_min * 0.99
            margem_max = y_max * 1.01

        ax.set_ylim(margem_min, margem_max)
        
        ax.axhline(y=media_janela, color='g', linestyle='--', label=f'Mean: {media_janela:.4f}')
        ax.axhline(y=media_janela + desvio_janela, color='r', linestyle=':', label=f'std: ±{desvio_janela:.4f}')
        if nome_coluna.startswith('PDT-') and (y_min/abs(y_min)) != (y_max/abs(y_max)):
            ax.axhline(y=rms_pdt_win, color='g', linestyle='-', label=f'RMS: {rms_pdt_win:.4f}')
        ax.axhline(y=media_janela - desvio_janela, color='r', linestyle=':')
        ax.legend(fontsize=8, loc='upper right')
        if linha == n_linhas - 1:
            ax.set_xlabel('Time (s)', fontsize=11)
        ax.set_ylabel(f"${apelido}$ {unidade}", fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='both', which='major', labelsize=9)
        
    for idx in range(len(colunas), n_linhas * n_colunas):
        linha = idx // n_colunas
        col = idx % n_colunas
        fig.delaxes(axs[linha, col])
    output_path = os.path.join(output_dir, f"windows-{base_name}.png")
    plt.savefig(output_path)
    plt.close(fig)

def uncert_propagation(df, colunas, start_idx, end_idx, best_window_size):
    """
    Propaga as incertezas das variáveis para a variável critério.
    Para cada coluna de interesse, calcula a média, o desvio padrão e a incerteza estatística tipo A (padrão da média) na janela selecionada.
    Retorna listas com os resultados para uso posterior.
    """
    n = end_idx - start_idx
    medias = []
    desvios = []
    uAs = []
    for coluna_info in colunas:
        nome_coluna = coluna_info[0]
        dados_janela = df[nome_coluna].iloc[start_idx:end_idx]
        media = dados_janela.mean()
        desvio = dados_janela.std(ddof=1)
        uA = desvio / (n ** 0.5)
        medias.append(media)
        desvios.append(desvio)
        uAs.append(uA)
    return [c[0] for c in colunas], medias, desvios, uAs

def calc_alpha(df, start_idx, end_idx):
    """
    Determina a fração de vazio (alpha) na mistura a partir dos dados do densitômetro na janela selecionada.
    Retorna um DataFrame contendo a série temporal de Alpha na janela.
    """
    dados_densitometro = df['Densitometro'].iloc[start_idx:end_idx]
    alpha_series = np.log(dados_densitometro / I_f) / np.log(I_g / I_f)
    
    alpha_df = pd.DataFrame({
        'X_Value': df['X_Value'].iloc[start_idx:end_idx],
        'Alpha': alpha_series
    })
    
    return alpha_df

def calc_frictional_pressure_gradient(df, colunas, start_idx, end_idx, best_window_size, alpha_series):
    """
    Calcula o gradiente de pressão friccional para cada variável na janela selecionada.
    Também encontra os índices das colunas que começam com 'PDT'.
    Calcula a série temporal da densidade do ar na janela usando a equação de estado.
    A pressão é lida como manométrica em bares e convertida para absoluta em Pascal.
    Armazena os resultados em um DataFrame dP_F_df e o retorna.
    """
    indices_pdt = [i for i, col in enumerate(colunas) if col[0].startswith("PDT")]

    try:
        pressao_ar_bar = df['PIT-M-0101'].iloc[start_idx:end_idx]
        temp_ar_celsius = df['TIT-M-0101'].iloc[start_idx:end_idx]
        
        pressao_ar_pa = (pressao_ar_bar + 1) * 1e5
        temp_ar_k = temp_ar_celsius + 273.15
        
        rho_ar = [PropsSI('D', 'P', p, 'T', t, 'Air') for p, t in zip(pressao_ar_pa, temp_ar_k)]
        rho_ar = pd.Series(rho_ar, index=pressao_ar_pa.index)
    
        try:
            temp_agua_celsius = df['TIT-M-0101'].iloc[start_idx:end_idx]
            temp_agua_k = temp_agua_celsius + 273.15
            rho_agua = [PropsSI('D', 'T', t, 'P', 101325, 'Water') for t in temp_agua_k]
            rho_agua = pd.Series(rho_agua, index=temp_agua_celsius.index)
        except Exception as e:
            rho_agua = 1000

    except KeyError as e:
        rho_ar = None

    dP_F_df = pd.DataFrame()

    for i in indices_pdt:
        coluna_pdt_nome = colunas[i][0]
        theta_rad = np.deg2rad(theta)

        if coluna_pdt_nome == sensor_Yokogawa:
            rho_tubbing = rho_s
        else:
            rho_tubbing = rho_agua
        
        delta_p_prime = df[coluna_pdt_nome].iloc[start_idx:end_idx]
        
        termo_gravitacional = ((1-alpha_series)*rho_agua + alpha_series*rho_ar - rho_tubbing) * g * np.sin(theta_rad)
        dP_dz_gravitacional = ((1-alpha_series)*rho_agua + alpha_series*rho_ar) * g * np.sin(theta_rad)

        if direction in ['Upward', 'Horizontal']:
            dP_F_over_dz_series = (delta_p_prime / L) - termo_gravitacional
            dP_F_over_dz_RMS = np.sqrt(np.mean(np.square(dP_F_over_dz_series)))
            dP_dz_total = dP_F_over_dz_RMS + np.mean(dP_dz_gravitacional)
        elif direction == 'Downward':
            dP_F_over_dz_series = -(delta_p_prime / L) + termo_gravitacional 
            dP_F_over_dz_RMS = np.sqrt(np.mean(np.square(dP_F_over_dz_series)))
            dP_dz_total = -(dP_F_over_dz_RMS) + np.mean(dP_dz_gravitacional)

        dP_F_df[coluna_pdt_nome] = dP_F_over_dz_series
        dP_F_df[f'dP_dz_total_{coluna_pdt_nome}'] = dP_dz_total
        if i == indices_pdt[0]:
            dP_F_df['dP_dz_gravitacional'] = dP_dz_gravitacional

    cols = [col for col in dP_F_df.columns if col != 'dP_dz_gravitacional']
    cols.append('dP_dz_gravitacional')
    dP_F_df = dP_F_df[cols]

    return dP_F_df

def extract_info_from_filename(filename: str):
    """
    Extrai informações do nome do arquivo experimental.
    Formato esperado: XXX##ID## onde:
    - X: letra indicando o fluido (A:Air, W:Water, O:Oil, S:SF6)
    - #: número indicando a inclinação em graus
    - ID: identificador do ponto experimental
    """
    fluid_map = {
        'A': 'Air',
        'W': 'Water',
        'O': 'Oil',
        'S': 'SF6',
        'D': 'Dense Fluid'
    }
    
    direction_map = {
        'H': 'Horizontal',
        'U': 'Upward',
        'D': 'Downward'
    }
    
    base_name = os.path.splitext(os.path.basename(filename))[0]
    
    fluid_1 = fluid_map.get(base_name[0], 'Unknown')
    fluid_2 = fluid_map.get(base_name[1], 'Unknown')
    direction = direction_map.get(base_name[2], 'Unknown')
    theta = int(base_name[3:5])
    ID = base_name[5:]
    
    return fluid_1, fluid_2, direction, theta, ID

def check_required_columns(df: pd.DataFrame, colunas_analise: list):
    """
    Verifica se as colunas necessárias existem no DataFrame.
    Retorna True se todas existirem, False caso contrário.
    """
    colunas_faltantes = []
    
    colunas_calculadas = ['Alpha', 'rho_g', 'J Ar corrigido']
    
    for coluna_info in colunas_analise:
        nome_coluna = coluna_info[0]
        if nome_coluna in colunas_calculadas:
            continue
        if nome_coluna not in df.columns:
            colunas_faltantes.append(nome_coluna)
    
    if colunas_faltantes:
        print("ERRO: As seguintes colunas não foram encontradas no arquivo:")
        for coluna in colunas_faltantes:
            print(f"- {coluna}")
        print("Por favor, verifique se o arquivo de entrada está correto.")
        return False
    
    return True

def plot_alpha(df: pd.DataFrame, start_idx: int, end_idx: int, output_dir: str, base_name: str):
    """
    Plota a série temporal de Alpha e salva a imagem.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados
        start_idx (int): Índice inicial da janela
        end_idx (int): Índice final da janela
        output_dir (str): Diretório para salvar a imagem
        base_name (str): Nome base para o arquivo de saída
    """
    alpha_df = calc_alpha(df, start_idx, end_idx)
    
    if alpha_df is not None and not alpha_df.empty:
        plt.figure(figsize=(15, 8))
        media_alpha = alpha_df['Alpha'].mean()
        plt.axhline(y=media_alpha, color='g', linestyle='--', label=f'Mean: {media_alpha:.4f}')
        plt.plot(alpha_df['X_Value'], alpha_df['Alpha'], label='Alpha')
        plt.xlabel('Time (s)', fontsize=12)
        plt.ylabel(r'$\alpha$', fontsize=12)
        plt.title(r'Void Fraction ($\alpha$)', fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.legend(fontsize=10)
        
        plt.tight_layout()
        output_path_alpha = os.path.join(output_dir, f"alpha-{base_name}.png")
        plt.savefig(output_path_alpha)
        plt.close(plt.gcf())
        return alpha_df
    else:
        return None

def plot_pressure_gradients(df: pd.DataFrame, dP_F_df: pd.DataFrame, start_idx: int, end_idx: int, output_dir: str, base_name: str, sensor_Yokogawa: str, sensor_Endress: str, direction: str):
    """
    Plota as séries temporais de gradientes de pressão e salva a imagem.
    
    Args:
        df (pandas.DataFrame): DataFrame com os dados
        dP_F_df (pandas.DataFrame): DataFrame com os gradientes de pressão
        start_idx (int): Índice inicial da janela
        end_idx (int): Índice final da janela
        output_dir (str): Diretório para salvar a imagem
        base_name (str): Nome base para o arquivo de saída
        sensor_Yokogawa (str): Nome do sensor Yokogawa
        sensor_Endress (str): Nome do sensor Endress
        direction (str): Direção do escoamento
    """
    if dP_F_df is not None and not dP_F_df.empty:
        plt.figure(figsize=(15, 8))
        
        grav_series = dP_F_df['dP_dz_gravitacional']
        grav_mean = grav_series.mean()
        grav_std = grav_series.std()
        plt.plot(df['X_Value'].iloc[start_idx:end_idx], grav_series, 
                label=f'dP/dz gravitacional\nmean: {grav_mean:.2f} ± {grav_std:.2f}', 
                color='black', linestyle='--')
        
        for col in dP_F_df.columns:
            if not col.startswith('dP_dz_total') and col != 'dP_dz_gravitacional':
                if col == sensor_Yokogawa:
                    sensor_range = col.split('-')[3]
                    label_base = f'Yokogawa {sensor_range}'
                elif col == sensor_Endress:
                    sensor_range = col.split('-')[3]
                    label_base = f'Endress {sensor_range}'
                else:
                    label_base = col
                
                series = dP_F_df[col]
                rms = np.sqrt(np.mean(np.square(series)))
                plt.plot(df['X_Value'].iloc[start_idx:end_idx], series, 
                        label=f'dP_F/dz {label_base}\nRMS: {rms:.2f}', 
                        alpha=0.7)

        for col in dP_F_df.columns:
            if col.startswith('dP_dz_total'):
                sensor_name = col.replace('dP_dz_total_', '')
                if sensor_name == sensor_Yokogawa:
                    sensor_range = sensor_name.split('-')[3]
                    label_base = f'Yokogawa {sensor_range}'
                elif sensor_name == sensor_Endress:
                    sensor_range = sensor_name.split('-')[3]
                    label_base = f'Endress {sensor_range}'
                else:
                    label_base = sensor_name
                
                dP_dz_total = dP_F_df[col].iloc[0]
                series = pd.Series([dP_dz_total] * len(dP_F_df), index=dP_F_df.index)
                
                plt.plot(df['X_Value'].iloc[start_idx:end_idx], series, 
                        label=f'dP/dz total {label_base}\nValue: {dP_dz_total:.2f}', 
                        linestyle=':', linewidth=2)
        
        plt.xlabel('Time (s)', fontsize=12)
        plt.ylabel(r'$ \frac{\Delta P}{L}$ [Pa/m]', fontsize=12)
        plt.title(r'Pressure Gradients', fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.legend(fontsize=10, bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        output_path_dpf = os.path.join(output_dir, f"dP_F_dz-{base_name}.png")
        plt.savefig(output_path_dpf, bbox_inches='tight')
        plt.close(plt.gcf())
    else:
        pass

if __name__ == "__main__":

    df, data_teste = read_file(file_path)

    if not check_required_columns(df, colunas_analise):
        sys.exit(1)

    fluid_1, fluid_2, direction, theta, ID = extract_info_from_filename(file_path)

    output_dir = os.path.dirname(file_path)
    base_name = os.path.splitext(os.path.basename(file_path))[0]

    if any(col[0] == 'Alpha' for col in colunas_analise):
        alpha_df_full = calc_alpha(df, 0, len(df))
        df['Alpha'] = alpha_df_full['Alpha'].values

    if any(col[0] == 'rho_g' for col in colunas_analise):
        try:
            pressao_ar_bar_full = df['PIT-M-0101']
            temp_ar_celsius_full = df['TIT-M-0101']
            pressao_ar_pa_full = (pressao_ar_bar_full + 1) * 1e5
            temp_ar_k_full = temp_ar_celsius_full + 273.15
            rho_g_full = [PropsSI('D', 'P', p, 'T', t, 'Air') for p, t in zip(pressao_ar_pa_full, temp_ar_k_full)]
            df['rho_g'] = rho_g_full
        except Exception as e:
            df['rho_g'] = (pressao_ar_pa_full) / (8.314 * temp_ar_k_full)

    dP_F_df_full = calc_frictional_pressure_gradient(df, colunas_analise, 0, len(df), len(df), alpha_df_full['Alpha'])
    for col in dP_F_df_full.columns:
        df[f'dP_F/dz {col}'] = dP_F_df_full[col].values

    colunas_analise_filtradas = [col for col in colunas_analise if col[0] in df.columns]
    if len(colunas_analise_filtradas) < len(colunas_analise):
        print("Atenção: Algumas colunas de análise não existem no DataFrame e não serão plotadas.")
        for col in colunas_analise:
            if col[0] not in df.columns:
                print(f"- Coluna ausente: {col[0]}")

    plot_time_series(df, colunas_analise_filtradas, output_dir, base_name)

    while True:
        escolha_janela = input("Como deseja definir a janela de análise?\n1. Definir manualmente (tempo inicial e tempo final)\n2. Encontrar janela ótima pelo tamanho (automático)\nDigite 1 para manual ou 2 para automático: ").strip()
        if escolha_janela in ['1', '2']:
            break
        print("Opção inválida. Digite 1 ou 2.")

    if escolha_janela == '1':
        while True:
            try:
                tempo_inicial = float(input("Digite o tempo inicial da janela (em segundos): "))
                tempo_final = float(input("Digite o tempo final da janela (em segundos): "))
                if tempo_final > tempo_inicial:
                    break
                else:
                    print("O tempo final deve ser maior que o inicial.")
            except ValueError:
                print("Entrada inválida. Digite valores numéricos.")
        start_idx = df[df['X_Value'] >= tempo_inicial].index[0]
        end_idx = df[df['X_Value'] <= tempo_final].index[-1] + 1
        coluna_escolhida = colunas_analise_filtradas[0][0]
        min_std = df[coluna_escolhida].iloc[start_idx:end_idx].std()
        best_window_size = df['X_Value'].iloc[end_idx-1] - df['X_Value'].iloc[start_idx]
        media_janela = df[coluna_escolhida].iloc[start_idx:end_idx].mean()
        min_window_size = best_window_size  # Define min_window_size para o caso manual
        max_window_size = best_window_size  # Define max_window_size para o caso manual
        print(f"Janela manual selecionada: {tempo_inicial:.2f}s a {tempo_final:.2f}s")
        print(f"Média da janela: {media_janela:.4f}")
        print(f"Desvio padrão: {min_std:.4f}")
        print(f"Tamanho da janela: {best_window_size:.1f} segundos")
    else:
        print("Colunas disponíveis para análise:")
        for i, col in enumerate(colunas_analise_filtradas, 1):
            print(f"{i}. {col[0]} ({col[1]})")
        
        while True:
            try:
                escolha = int(input("Escolha o número da variável para usar como critério de janelamento: "))
                if 1 <= escolha <= len(colunas_analise_filtradas):
                    coluna_escolhida = colunas_analise_filtradas[escolha-1][0]
                    print(f"Variável escolhida: {coluna_escolhida}")
                    break
                else:
                    print(f"Por favor, escolha um número entre 1 e {len(colunas_analise_filtradas)}")
            except ValueError:
                print("Entrada inválida. Digite um número válido.")

        while True:
            try:
                min_window_size = float(input("Digite o tamanho mínimo da janela em segundos: "))
                if min_window_size > 0:
                    break
                else:
                    print("O tamanho mínimo da janela deve ser maior que zero.")
            except ValueError:
                print("Entrada inválida. Por favor, digite um número válido.")
        while True:
            try:
                max_window_size = float(input("Digite o tamanho máximo da janela em segundos: "))
                if max_window_size >= min_window_size:
                    break
                else:
                    print("O tamanho máximo da janela deve ser maior ou igual ao tamanho mínimo.")
            except ValueError:
                print("Entrada inválida. Por favor, digite um número válido.")
        start_idx, end_idx, min_std, best_window_size = find_min_std_window(
            df, coluna_escolhida, min_window_size, max_window_size)
        media_janela = df[coluna_escolhida].iloc[start_idx:end_idx].mean()
        print(f"Janela ótima selecionada: {df['X_Value'].iloc[start_idx]:.2f}s a {df['X_Value'].iloc[end_idx-1]:.2f}s")
        print(f"Média da janela: {media_janela:.4f}")
        print(f"Desvio padrão: {min_std:.4f}")
        print(f"Tamanho da janela: {best_window_size:.1f} segundos")

    print("\nCalculando e exibindo a incerteza tipo A para cada variável na janela...")
    nomes, medias, desvios, uAs = uncert_propagation(df, colunas_analise_filtradas, start_idx, end_idx, best_window_size)
    
    plt.figure(figsize=(15, 8))
    
    plt.plot(df['X_Value'], df[coluna_escolhida], 'b-', label='Full Series', alpha=0.7)
    
    plt.axvspan(df['X_Value'].iloc[start_idx], df['X_Value'].iloc[end_idx-1], alpha=0.3, color='red', label=f'Window = {best_window_size:.0f} s')
    
    plt.axhline(y=media_janela, color='g', linestyle='--', label=f'Mean: {media_janela:.4f}')
    
    apelido_escolhido = coluna_escolhida
    unidade_escolhida = ''
    for col in colunas_analise_filtradas:
        if isinstance(col, (list, tuple)) and col[0] == coluna_escolhida:
            apelido_escolhido = col[1]
            unidade_escolhida = col[2]
            break
    
    plot_windows(df, colunas_analise_filtradas, start_idx, end_idx, best_window_size, output_dir, base_name)
    
    alpha_df = plot_alpha(df, start_idx, end_idx, output_dir, base_name)
    
    alpha_series = alpha_df['Alpha'] if alpha_df is not None else None
    dP_F_df = calc_frictional_pressure_gradient(df, colunas_analise_filtradas, start_idx, end_idx, best_window_size, alpha_series=alpha_series)
    
    save_results(df, coluna_escolhida, start_idx, end_idx, min_std, media_janela,
                min_window_size, max_window_size, best_window_size, file_path, data_teste,
                fluid_1, fluid_2, direction, theta, ID,
                nomes=colunas_analise_filtradas, medias=medias, desvios=desvios, uAs=uAs,
                escolha_janela=escolha_janela)
    
    plot_pressure_gradients(df, dP_F_df, start_idx, end_idx, output_dir, base_name, sensor_Yokogawa, sensor_Endress, direction)
    print("Arquivo excel dos dados tratados criado...")

    print('##########################################################################')
    print('#AEEEE! Parabéns executado com sucesso, boa sorte com a análise de dados!#')
    print('##########################################################################')